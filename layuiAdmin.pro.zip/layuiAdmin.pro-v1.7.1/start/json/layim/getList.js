{
  "code": 0
  ,"msg": ""
  ,"data": {
    "mine": {
      "username": "测试名称"
      ,"id": "100000"
      ,"status": "online"
      ,"sign": "测试"
      ,"avatar": ""
    }
    ,"friend": [{
      "groupname": "测试分组一"
      ,"id": 0
      ,"list": [{
        "username": "测试1"
        ,"id": "100001"
        ,"avatar": ""
        ,"sign": "测试内容1"
        ,"status": "online"
      },{
        "username": "测试2"
        ,"id": "100001222"
        ,"sign": "测试内容2"
        ,"avatar": ""
      },{
        "username": "测试3"
        ,"id": "10034001"
        ,"avatar": ""
        ,"sign": ""
      },{
        "username": "测试4"
        ,"id": "168168"
        ,"avatar": ""
        ,"sign": "测试内容4"
      },{
        "username": "测试5"
        ,"id": "666666"
        ,"avatar": ""
        ,"sign": "测试内容5"
      }]
    },{
      "groupname": "测试分组二"
      ,"id": 1
      ,"list": [{
        "username": "测试6"
        ,"id": "121286"
        ,"avatar": ""
        ,"sign": "测试内容6"
      },{
        "username": "测试7"
        ,"id": "108101"
        ,"avatar": ""
        ,"sign": "微电商达人"
      },{
        "username": "测试8"
        ,"id": "12123454"
        ,"avatar": ""
        ,"sign": "测试内容8"
      },{
        "username": "测试9"
        ,"id": "102101"
        ,"avatar": ""
        ,"sign": ""
      },{
        "username": "测试10"
        ,"id": "3435343"
        ,"avatar": ""
        ,"sign": ""
      }]
    },{
      "groupname": "测试分组三"
      ,"id": 2
      ,"list": [{
        "username": "测试11"
        ,"id": "76543"
        ,"avatar": ""
        ,"sign": "测试内容11"
      },{
        "username": "测试12"
        ,"id": "4803920"
        ,"avatar": ""
        ,"sign": "测试内容12"
      }]
    }]
    ,"group": [{
      "groupname": "测试群组一"
      ,"id": "101"
      ,"avatar": ""
    },{
      "groupname": "测试群组二"
      ,"id": "102"
      ,"avatar": ""
    }]
  }
}